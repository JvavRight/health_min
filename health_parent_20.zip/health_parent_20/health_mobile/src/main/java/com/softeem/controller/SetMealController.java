package com.softeem.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.softeem.constant.MessageConstant;
import com.softeem.entity.Result;
import com.softeem.pojo.SetMeal;
import com.softeem.service.SetMealService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/setmeal")
public class SetMealController {
    /*@Autowired：这是Spring框架提供的注解，
        用于实现依赖注入（Dependency Injection, DI）。
        当我们在Spring管理的Bean（如Spring MVC、Spring Boot应用中的类）中需要注入其他Bean作为依赖时，
        可以使用@Autowired注解。它适用于所有基于Spring框架的应用程序，
        包括Spring Boot、Spring Cloud等。
    @Reference：这是Dubbo框架（一个高性能、轻量级的Java RPC框架）提供的注解，
        同样用于实现依赖注入。当我们的服务消费者需要引用远程服务提供者的接口时，
        使用@Reference注解进行注入。
        它专属于Dubbo框架及其相关生态系统，用于构建分布式服务调用场景。*/
    @Reference
    private SetMealService setMealService;

    @RequestMapping("/getSetMeal")
    public Result getSetMeal() {
        try {
            List<SetMeal> setMealList = setMealService.findAll();
            return new Result(true, MessageConstant.GET_SETMEAL_LIST_SUCCESS, setMealList);
        } catch (Exception e) {
            return new Result(false, MessageConstant.GET_SETMEAL_LIST_FAIL);
        }
    }

    @RequestMapping("/findById")
    public Result findById(Integer id) {
        try {
            SetMeal setMeal = setMealService.findById(id);
            return new Result(true, MessageConstant.QUERY_SETMEAL_SUCCESS, setMeal);
        } catch (Exception e) {
            return new Result(false, MessageConstant.QUERY_SETMEAL_FAIL);
        }
    }
}
