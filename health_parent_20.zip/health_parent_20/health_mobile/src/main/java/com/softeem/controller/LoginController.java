package com.softeem.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSON;
import com.softeem.constant.MessageConstant;
import com.softeem.constant.RedisMessageConstant;
import com.softeem.entity.Result;
import com.softeem.pojo.Member;
import com.softeem.service.MemberService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import redis.clients.jedis.JedisPool;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.Map;

@RestController
@RequestMapping("/login")
public class LoginController {
    @Autowired
    private JedisPool jedisPool;
    @Reference
    private MemberService memberService;

    @RequestMapping("/check")
    public Result checkLogin(@RequestBody Map map, HttpServletResponse response) {
        String telephone = (String) map.get("telephone");
        String validateCode = (String) map.get("validateCode");
        String redisCode = jedisPool.getResource().get(telephone + RedisMessageConstant.SENDTYPE_LOGIN);

        // 校验验证码
        if (validateCode != null && validateCode.equals(redisCode)) {
            Member member = memberService.findByTelephone(telephone);
            // 判断是否为新用户, 如果是新用户就自动完成注册
            if (member == null) {
                member = new Member();
                member.setPhoneNumber(telephone);
                member.setRegTime(new Date());
                memberService.add(member);// 注册(添加会员,只有手机号和注册时间,其它信息为null)
            }
            // 登录成功, 写入Cookie, 跟踪客户
            Cookie cookie = new Cookie("login_member_telephone", telephone);
            cookie.setPath("/");// 设置Cookie的路径
            cookie.setMaxAge(60 * 60 * 24);// Cookie有效期1天
            response.addCookie(cookie);
            // 保存会员信息到Redis
            String jsonMember = JSON.toJSON(member).toString();
            // 保存会员信息到Redis是为了登录成功后从Redis中获取会员信息, 表示此用户已经登录
            jedisPool.getResource().setex(telephone, 60 * 30, jsonMember);
            return new Result(true, MessageConstant.LOGIN_SUCCESS);
        } else {
            return new Result(false, MessageConstant.VALIDATECODE_ERROR);
        }

    }
}
