package com.softeem.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.softeem.constant.MessageConstant;

import com.softeem.constant.RedisMessageConstant;
import com.softeem.entity.Result;
import com.softeem.pojo.Order;
import com.softeem.service.OrderService;
import com.softeem.utils.SMSUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import redis.clients.jedis.JedisPool;

import java.util.Map;

@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private JedisPool jedisPool;
    @Reference
    private OrderService orderService;
    private String type = "orderType";
    private String code = "666";

    @RequestMapping("/submit")
    public Result submitOrder(@RequestBody Map map) {
        // 校验验证码
        String validateCode = (String) map.get("validateCode");// 获取用户提交的验证码
        String telephone = (String) map.get("telephone");
        // 从redis中获取验证码
        String redisValidateCode = jedisPool.getResource().get(telephone + RedisMessageConstant.SENDTYPE_ORDER);
        // 判断验证码是否正确
        if (redisValidateCode == null || !redisValidateCode.equals(validateCode)) {
            return new Result(false, MessageConstant.VALIDATECODE_ERROR);
        }
        Result result = null;
        try {
            // 设置用户预约的类型
            map.put(type, Order.ORDERTYPE_WEIXIN);
            result = orderService.order(map);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, MessageConstant.ORDER_FAIL);
        }
        // 预约成功,发送短信通知
        if (result != null && result.isFlag()) {
            SMSUtils.sendShortMessage(SMSUtils.VALIDATE_CODE, telephone, code);
            // 预约成功,删除验证码
            jedisPool.getResource().del(telephone + RedisMessageConstant.SENDTYPE_ORDER);
        }
        return result;
    }

    @RequestMapping("/findById")
    public Result findById(Integer id) {
        try {
            Map map = orderService.findById(id);
            return new Result(true, MessageConstant.QUERY_ORDER_SUCCESS, map);//查询预约信息成功
        } catch (Exception e) {
            return new Result(false, MessageConstant.QUERY_ORDER_FAIL);//查询预约信息失败
        }
    }
}
