package com.softeem.controller;

import com.softeem.constant.MessageConstant;
import com.softeem.constant.RedisMessageConstant;
import com.softeem.entity.Result;
import com.softeem.utils.SMSUtils;
import com.softeem.utils.ValidateCodeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import redis.clients.jedis.JedisPool;

@RestController
@RequestMapping("/validateCode")
public class ValidateCodeController {

    @Autowired
    private JedisPool jedisPool;

    @RequestMapping("/send4Order")
    public Result getValidateCode(String telephone) {
        try {
            // 生成验证码
            String code = ValidateCodeUtils.generateValidateCode(4) + "";
            System.out.println(code);
            // 将验证码保存到redis, 并设置过期时间(5分钟)
            jedisPool.getResource().setex(telephone + RedisMessageConstant.SENDTYPE_ORDER, 5 * 60, code);
            // 发送验证码
            SMSUtils.sendShortMessage(SMSUtils.VALIDATE_CODE, telephone, code);
            return new Result(true, MessageConstant.SEND_VALIDATECODE_SUCCESS);
        } catch (Exception e) {
            return new Result(false, MessageConstant.SEND_VALIDATECODE_FAIL);
        }
    }

    @RequestMapping("/send4Login")
    public Result getValidateCode4Login(String telephone) {
        try {
            // 生成验证码
            String code = ValidateCodeUtils.generateValidateCode(4) + "";
            System.out.println(code);
            // 将验证码保存到redis, 并设置过期时间(5分钟)
            jedisPool.getResource().setex(telephone + RedisMessageConstant.SENDTYPE_LOGIN, 5 * 60, code);
            // 发送验证码
            //SMSUtils.sendShortMessage(SMSUtils.VALIDATE_CODE, telephone, code);
            return new Result(true, MessageConstant.SEND_VALIDATECODE_SUCCESS);
        } catch (Exception e) {
            return new Result(false, MessageConstant.SEND_VALIDATECODE_FAIL);
        }
    }
}
