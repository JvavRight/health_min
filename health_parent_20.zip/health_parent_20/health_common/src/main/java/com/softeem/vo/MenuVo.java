package com.softeem.vo;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class MenuVo implements Serializable {
    private Integer id;//菜单主键id
    private String label;//菜单名称
    private Integer parentmenuid;//父菜单id
    private List<MenuVo> children = new ArrayList<>();//子菜单

    public MenuVo() {
    }

    public MenuVo(Integer id, String label, Integer parentmenuid, List<MenuVo> children) {
        this.id = id;
        this.label = label;
        this.parentmenuid = parentmenuid;
        this.children = children;
    }

    /**
     * 获取
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取
     * @return label
     */
    public String getLabel() {
        return label;
    }

    /**
     * 设置
     * @param label
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * 获取
     * @return parentmenuid
     */
    public Integer getParentmenuid() {
        return parentmenuid;
    }

    /**
     * 设置
     * @param parentmenuid
     */
    public void setParentmenuid(Integer parentmenuid) {
        this.parentmenuid = parentmenuid;
    }

    /**
     * 获取
     * @return children
     */
    public List<MenuVo> getChildren() {
        return children;
    }

    /**
     * 设置
     * @param children
     */
    public void setChildren(List<MenuVo> children) {
        this.children = children;
    }

    public String toString() {
        return "MenuVo{id = " + id + ", label = " + label + ", parentmenuid = " + parentmenuid + ", children = " + children + "}";
    }
}
