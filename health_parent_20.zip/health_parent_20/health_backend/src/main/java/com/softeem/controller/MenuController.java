package com.softeem.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.softeem.constant.MessageConstant;
import com.softeem.entity.QueryPageBean;
import com.softeem.entity.Result;
import com.softeem.pojo.Menu;
import com.softeem.service.MenuService;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/menu")
public class MenuController {
    @Reference
    private MenuService menuService;

    @RequestMapping("/showPage")
    public Result findPage(@RequestBody QueryPageBean queryPageBean) {
        Map map = menuService.findPage(queryPageBean);
        return new Result(true, "成功", map);
    }
    @RequestMapping("/add")
    public Result add(@RequestBody Menu menu) {
        try {
            menuService.save(menu);
            return new Result(true, "添加菜单成功");
        } catch (Exception e) {
            return new Result(false, "添加菜单失败");
        }
    }
    @RequestMapping("/edit")
    public Result edit(@RequestBody Menu menu) {
        try {
            menuService.update(menu);
            return new Result(true, "编辑菜单成功");
        } catch (Exception e) {
            return new Result(false, "编辑菜单失败");
        }
    }
    @RequestMapping("/findById")
    public Result findById(Integer id) {
        try {
            Menu menu = menuService.findById(id);
            return new Result(true, "获取菜单数据成功",menu);
        } catch (Exception e) {
            return new Result(false, "获取菜单数据失败");
        }
    }
    @RequestMapping("/delete")
    public Result delete(Integer id) {
        try {
            menuService.delete(id);
            return new Result(true, "删除菜单成功");
        } catch (Exception e) {
            return new Result(false, "删除菜单失败");
        }
    }
    @RequestMapping("/getMenu")
    public Result getMenu() {
        try {
            // 获取当前登录用户[此用户是springSecurity 封装的user对象,而不是自己封装pojo的user对象]
            User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            List<Menu> menus = menuService.getMenu(user.getUsername());// 根据用户名获取菜单
            return new Result(true, MessageConstant.GET_MENU_SUCCESS, menus);
        } catch (Exception e) {
            return new Result(false, MessageConstant.GET_MENU_FAIL);
        }
    }
}
