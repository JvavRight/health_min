package com.softeem.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.softeem.constant.MessageConstant;
import com.softeem.entity.PageResult;
import com.softeem.entity.QueryPageBean;
import com.softeem.entity.Result;
import com.softeem.pojo.User;
import com.softeem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserController {
    @Reference
    private UserService userService;

    @RequestMapping("/getUsername")
    public Result getUsername() {
        try {
            // 获取当前登录用户[此用户时springSecurity 封装的user对象,而不是自己封装pojo的user对象]
            org.springframework.security.core.userdetails.User user
                    = (org.springframework.security.core.userdetails.User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            return new Result(true, MessageConstant.GET_USERNAME_SUCCESS, user.getUsername());
        } catch (Exception e) {
            return new Result(false, MessageConstant.GET_USERNAME_FAIL);
        }
    }

    @RequestMapping("/editRoles")
    public Result editRoles(Integer[] roleIds, Integer id) {
        try {
            userService.editRoles(roleIds, id);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, "修改用户角色失败");
        }
        return new Result(true, "修改用户角色成功");
    }

    @RequestMapping("/findPage")
    public PageResult findPage(@RequestBody QueryPageBean queryPageBean) {
        PageResult pageResult = userService.findByPage(queryPageBean);
        return pageResult;
    }

    @RequestMapping("/add")
    public Result findPage(@RequestBody User user) {
        System.out.println("user = " + user);
        try {
            userService.save(user);
            return new Result(true, "新增用户成功");
        } catch (Exception e) {
            return new Result(false, "新增用户失败");
        }
    }

    @RequestMapping("/edit")
    public Result edit(@RequestBody User user) {
        try {
            userService.update(user);
            return new Result(true, "修改用户数据成功");
        } catch (Exception e) {
            return new Result(false, "修改用户数据失败");
        }
    }

    @RequestMapping("/findById")
    public Result edit(Integer id) {
        try {
            User user = userService.findById(id);
            return new Result(true, "获取用户数据成功", user);
        } catch (Exception e) {
            return new Result(false, "获取用户数据失败");
        }
    }

    @RequestMapping("/delete")
    public Result delete(Integer id) {
        try {
            userService.delete(id);
            return new Result(true, "删除用户数据成功");
        } catch (Exception e) {
            return new Result(false, "删除用户数据失败");
        }
    }
}
