package com.softeem.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.softeem.constant.MessageConstant;
import com.softeem.constant.RedisConstant;
import com.softeem.entity.PageResult;
import com.softeem.entity.QueryPageBean;
import com.softeem.entity.Result;
import com.softeem.pojo.SetMeal;
import com.softeem.service.SetMealService;
import com.softeem.utils.ALiYunUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import redis.clients.jedis.JedisPool;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/setmeal")
public class SetMealController {
    @Reference
    private SetMealService setMealService;
    @Autowired
    private JedisPool jedisPool;

    //图片上传
    @RequestMapping("/upload")
    public Result upload(@RequestParam("imgFile") MultipartFile imgFile) {
        try {
            System.out.println(imgFile.getName());
            //获取原始文件名
            String originalFilename = imgFile.getOriginalFilename();
            //获取文件后缀 ( .jpg)
            int lastIndexOf = originalFilename.lastIndexOf(".");
            //获取文件后缀[jpg]
            String suffix = originalFilename.substring(lastIndexOf);
            //使用UUID随机产生文件名称，防止同名文件覆盖
            String fileName = UUID.randomUUID().toString() + suffix;

            //上传到阿里云
            ALiYunUtils.upload2ALiYun(imgFile.getBytes(), fileName);
            //图片上传成功
            Result result = new Result(true, MessageConstant.PIC_UPLOAD_SUCCESS,
                    "https://qinmincai.oss-cn-hangzhou.aliyuncs.com/" + fileName);
            //将上传图片名称存入Redis，基于Redis的Set集合存储(大集合中)
            jedisPool.getResource().sadd(RedisConstant.SETMEAL_PIC_RESOURCES,
                    "https://qinmincai.oss-cn-hangzhou.aliyuncs.com/" + fileName);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            //图片上传失败
            return new Result(false, MessageConstant.PIC_UPLOAD_FAIL);
        }
    }

    @RequestMapping("/findPage")
    public PageResult findPage(@RequestBody QueryPageBean queryPageBean) {
        return setMealService.findPage(queryPageBean);
    }

    // 添加套餐
    @RequestMapping("/add")
    public Result add(@RequestBody SetMeal setMeal, Integer[] checkGroupIds) {
        try {
            setMealService.add(setMeal, checkGroupIds);
            return new Result(true, MessageConstant.ADD_SETMEAL_SUCCESS);
        } catch (Exception e) {
            return new Result(false, MessageConstant.ADD_SETMEAL_FAIL);
        }
    }

    // 根据套餐id获取检查组id集合
    @RequestMapping("/getCheckGroupIdsBySetMealId")
    public Result getCheckGroupIdsBySetMealId(Integer setMealId) {
        try {
            List<Integer> checkGroupIds = setMealService.getCheckGroupIdsBySetMealId(setMealId);
            return new Result(true, MessageConstant.QUERY_CHECKGROUP_SUCCESS, checkGroupIds);
        } catch (Exception e) {
            return new Result(false, MessageConstant.QUERY_CHECKGROUP_FAIL);
        }
    }

    // 编辑套餐
    @RequestMapping("/edit")
    public Result edit(@RequestBody SetMeal setMeal, Integer[] checkGroupIds) {
        try {
            setMealService.edit(setMeal, checkGroupIds);
            return new Result(true, MessageConstant.EDIT_SETMEAL_SUCCESS);
        } catch (Exception e) {
            return new Result(false, MessageConstant.EDIT_SETMEAL_FAIL);
        }
    }

    /**
     * 删除套餐
     */
    @RequestMapping("/delete")
    public Result delete(Integer id) {
        try {
            setMealService.deleteSetMeal(id);
            return new Result(true, MessageConstant.DELETE_SETMEAL_SUCCESS);
        } catch (Exception e) {
            return new Result(false, MessageConstant.DELETE_SETMEAL_FAIL);
        }
    }

    @RequestMapping("/generateStaticHtml")
    public Result generateStaticHtml() {
        try {
            setMealService.generateMobileStaticHtml();
            return new Result(true, "成功!");
        } catch (Exception e) {
            return new Result(false, "失败!");
        }
    }
}
