package com.softeem.controller;


import com.alibaba.dubbo.config.annotation.Reference;
import com.softeem.entity.PageResult;
import com.softeem.entity.QueryPageBean;
import com.softeem.entity.Result;
import com.softeem.pojo.Permission;
import com.softeem.pojo.Role;
import com.softeem.service.PermissionService;
import com.softeem.service.RoleService;
import com.softeem.service.UserService;
import com.softeem.vo.MenuVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/role")
public class RoleController {
    @Reference
    private RoleService roleService;
    @Reference
    private UserService userService;
    @Reference
    private PermissionService permissionService;

    /**
     * 根据角色id查询权限列表
     *
     * @param roleId
     * @return
     */
    @GetMapping("/findPermissionList")
    public Result findPermissionList(@RequestParam(name = "roleId", defaultValue = "") String roleId) {
        try {
            List<Permission> permissionList = permissionService.findAll();
            List<Integer> permissionIds = roleService.findPermissionIdsByRoleId(Integer.parseInt(roleId));
            Map map = new HashMap();
            map.put("permissionList", permissionList);
            map.put("permissionIds", permissionIds);
            return new Result(true, "权限列表查询成功", map);
        } catch (Exception e) {
            return new Result(false, "权限列表查询失败");
        }
    }

    @GetMapping("/updatePermissionByRoleId")
    public Result updatePermissionByRoleId(@RequestParam(name = "roleId", defaultValue = "0") Integer roleId,
                                           @RequestParam(name = "permissionIds", defaultValue = "") List<Integer> permissionIds) {
        try {
            roleService.updatePermissionByRoleId(permissionIds, roleId);
            return new Result(true, "权限更新成功");
        } catch (Exception e) {
            return new Result(false, "权限更新失败");
        }
    }

    @RequestMapping("/updateMenuByRoleId")
    public Result updateMenuByRoleId(Integer[] menuIds, Integer roleId) {
        try {
            roleService.updateMenuByRoleId(menuIds, roleId);
            return new Result(true, "菜单设置成功");
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, "菜单设置失败");
        }
    }

    @RequestMapping("/findMenuListByRoleId")
    public Result findMenuListByRoleId(Integer id) {
        try {
            List<MenuVo> menuVoList = roleService.findMenu();
            List<Integer> menuIds = roleService.findMenuByRoleId(id);
            Map map = new HashMap();
            map.put("menuVoList", menuVoList);
            map.put("menuIds", menuIds);
            return new Result(true, "菜单查询成功", map);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, "菜单查询失败");
        }
    }

    @RequestMapping("/findAll")
    public Result findAll(Integer id) {
        System.out.println("id = " + id);
        List<Role> roleList = null;
        Map map = new HashMap();
        try {

            roleList = roleService.findAll();
            List<Integer> roleIds = userService.getRoleIds(id);
            map.put("roleList", roleList);
            map.put("roleIds", roleIds);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, "查询所有角色失败");
        }
        return new Result(true, "查询所有角色成功", map);
    }

    @RequestMapping("/findPage")
    public PageResult findPage(@RequestBody QueryPageBean queryPageBean) {
        System.out.println("queryPageBean = " + queryPageBean);
        PageResult pageResult = roleService.findPage(queryPageBean);
        return pageResult;
    }

    @RequestMapping("/add")
    public Result add(@RequestBody Role role) {
        try {
            roleService.save(role);
            return new Result(true, "新增角色成功");
        } catch (Exception e) {
            return new Result(false, "新增角色失败");
        }
    }

    @RequestMapping("/findById")
    public Result findById(Integer id) {
        try {
            Role role = roleService.findById(id);
            return new Result(true, "获取角色成功", role);
        } catch (Exception e) {
            return new Result(false, "获取角色失败");
        }
    }

    @RequestMapping("/edit")
    public Result findById(@RequestBody Role role) {
        try {
            roleService.updateRole(role);
            return new Result(true, "编辑角色成功");
        } catch (Exception e) {
            return new Result(false, "编辑角色失败");
        }
    }

    @RequestMapping("/delete")
    public Result delete(Integer id) {
        try {
            roleService.deleteById(id);
            return new Result(true, "删除角色成功");
        } catch (Exception e) {
            return new Result(false, "删除角色失败");
        }
    }
}
