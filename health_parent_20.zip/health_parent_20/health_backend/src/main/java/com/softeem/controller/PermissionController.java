package com.softeem.controller;


import com.alibaba.dubbo.config.annotation.Reference;
import com.softeem.entity.PageResult;
import com.softeem.entity.QueryPageBean;
import com.softeem.entity.Result;
import com.softeem.pojo.Permission;
import com.softeem.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/permission")
public class PermissionController {
    @Reference
    private PermissionService permissionService;

    @RequestMapping("/findPage")
    public PageResult findPage(@RequestBody QueryPageBean queryPageBean) {
        System.out.println("queryPageBean = " + queryPageBean);
        PageResult pageResult = permissionService.findPage(queryPageBean);
        return pageResult;
    }

    @RequestMapping("/add")
    public Result add(@RequestBody Permission permission) {
        try {
            permissionService.save(permission);
            return new Result(true, "新增权限成功");
        } catch (Exception e) {
            return new Result(false, "新增权限失败");
        }
    }
    @RequestMapping("/findById")
    public Result findById(Integer id) {
        try {
            Permission permission = permissionService.findById(id);
            return new Result(true, "获取权限成功",permission);
        } catch (Exception e) {
            return new Result(false, "获取权限失败");
        }
    }
    @RequestMapping("/edit")
    public Result findById(@RequestBody Permission permission) {
        try {
            permissionService.updatePermission(permission);
            return new Result(true, "编辑权限成功");
        } catch (Exception e) {
            return new Result(false, "编辑权限失败");
        }
    }
    @RequestMapping("/delete")
    public Result delete(Integer id) {
        try {
            permissionService.deleteById(id);
            return new Result(true, "删除权限成功");
        } catch (Exception e) {
            return new Result(false, "删除权限失败");
        }
    }
}
