package com.softeem.service;


import com.softeem.entity.PageResult;
import com.softeem.entity.QueryPageBean;
import com.softeem.pojo.Role;
import com.softeem.vo.MenuVo;

import java.util.List;

public interface RoleService {

    PageResult findPage(QueryPageBean queryPageBean);

    void save(Role role);

    Role  findById(Integer id);

    void updateRole(Role role);

    void deleteById(Integer id);

    List<Role> findAll();

    List<MenuVo> findMenu();

    List<Integer> findMenuByRoleId(Integer id);

    void  updateMenuByRoleId(Integer [] menuIds , Integer roleId);

    void updatePermissionByRoleId(List<Integer> permissionIds, Integer roleId);

    List<Integer> findPermissionIdsByRoleId(Integer roleId);
}
