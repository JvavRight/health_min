package com.softeem.service;


import com.softeem.entity.PageResult;
import com.softeem.entity.QueryPageBean;
import com.softeem.pojo.Permission;

import java.util.List;

public interface PermissionService {

    PageResult findPage(QueryPageBean queryPageBean);

    List<Permission> findAll();

    void save(Permission permission);

    Permission  findById(Integer id);

    void updatePermission(Permission permission);

    void deleteById(Integer id);


}
