package com.softeem.service;

import com.softeem.entity.QueryPageBean;
import com.softeem.pojo.Menu;

import java.util.List;
import java.util.Map;

public interface MenuService {
    List<Menu> getMenu(String username);

    Map findPage(QueryPageBean queryPageBean);

    void save(Menu menu);

    Menu findById(Integer id);

    void update(Menu menu);

    void delete(Integer id);
}
