package com.softeem.service;

import com.softeem.entity.PageResult;
import com.softeem.entity.QueryPageBean;
import com.softeem.pojo.SetMeal;

import java.util.List;
import java.util.Map;

public interface SetMealService {
    PageResult findPage(QueryPageBean queryPageBean);

    void add(SetMeal setMeal, Integer[] checkGroupIds);

    List<Integer> getCheckGroupIdsBySetMealId(Integer setMealId);

    void edit(SetMeal setMeal, Integer[] checkGroupIds);

    void deleteSetMeal(Integer id);

    List<SetMeal> findAll();

    SetMeal findById(Integer id);

    void generateMobileStaticHtml();

    List<Map<String, Object>> findSetmealCount();

}
