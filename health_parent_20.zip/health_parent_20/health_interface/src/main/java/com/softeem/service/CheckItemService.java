package com.softeem.service;

import com.softeem.entity.PageResult;
import com.softeem.pojo.CheckItem;

import java.util.List;

public interface CheckItemService {

    /**
     * 检查项服务接口
     */
    void add(CheckItem checkItem);

    /*
     * 查询检查项
     * */
    PageResult pageQuery(Integer currentPage, Integer pageSize, String queryString);

    /*
     * 删除检查项
     * */
    void deleteById(Integer id);

    /*
     * 编辑检查项
     * */
    void edit(CheckItem checkItem);

    List<CheckItem> findAll();
}
