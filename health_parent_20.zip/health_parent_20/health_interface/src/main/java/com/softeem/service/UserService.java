package com.softeem.service;

import com.softeem.entity.PageResult;
import com.softeem.entity.QueryPageBean;
import com.softeem.pojo.User;

import java.util.List;

public interface UserService {
    User findByUsername(String username);

    PageResult findByPage(QueryPageBean queryPageBean);

    void save(User user);

    User findById(Integer id);

    void update(User user);

    void delete(Integer id);

    List<Integer> getRoleIds(Integer id);
    void editRoles(Integer [] roleIds , Integer id);
}
