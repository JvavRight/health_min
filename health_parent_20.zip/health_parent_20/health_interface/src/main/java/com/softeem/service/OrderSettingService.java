package com.softeem.service;

import com.softeem.pojo.OrderSetting;
import java.util.List;
import java.util.Map;

public interface OrderSettingService {
    public void add(List<OrderSetting> list);

    List<Map> getOrderSettingByMonth(String date);

    void editNumberByOrderDate(OrderSetting orderSetting);
}